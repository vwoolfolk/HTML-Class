// $("#main").append("Vernisha Woolfolk");

 // bio section // 
 
   var bio = {
    'name': "Vernisha Woolfolk",
    'role': "Web Designer",
    'contact': {
       'email': "vwoolfolk10@yahoo.com",
       'github': "vwoolfolk",
       'location': "Romulus, Michigan",
       'mobile': "734.765.4458"
      },
    'pic': ["images/Vernisha.jpg"], 
    'message': "Expressive Design", 
    'skills': ['HTML/CSS', 'SQL', 'JavaScript', 'Design', 'Microsoft Office']
 };

 var formattedName = HTMLheaderName.replace("%data%", "Vernisha Woolfolk");

 var formattedRole = HTMLheaderRole.replace("%data%", "Web Designer");

 $("#header").prepend(formattedName);
 $("#header").prepend(formattedRole);

 var _location = bio.contact.location;
 var formattedLocation = HTMLlocation.replace("%data%", _location);
 $("#topContacts").prepend(formattedLocation);


 var mobile = bio.contact.mobile;
 var formattedMobile = HTMLmobile.replace("%data%", mobile);
 $("#topContacts").prepend(formattedMobile);


 var github = bio.contact.github;
 var formattedGithub = HTMLgithub.replace("%data%", github);
 $("#topContacts").prepend(formattedGithub);

 var email = bio.contact.email;
 var formattedEmail = HTMLemail.replace("%data%", email);
 $("#topContacts").prepend(formattedEmail);


 var message = bio.message;
 var welcome_msg = HTMLwelcomeMsg.replace("%data%",message);
 $("#header").prepend(welcome_msg);

 var biopic = bio.pic;
 var formattedBiopic = HTMLbioPic.replace("%data%", biopic);
 $("#header").append(formattedBiopic);

 $("#header").append(HTMLskillsStart);

 var skills = bio.skills;

 for (var i=0; i<skills.length; i++){
 var formattedskills = HTMLskills.replace("%data%", skills[i]);
 $("#header").append(formattedskills);
 }
 

 

 // work section //
  
 var work = {
 "jobs": [
 {
        "employer": "AT&T Uverse",
        "title": "Capacity Planning Manager", 
		"location":"Southfield, Michigan",
        "dates": "In progress",
		"description": "Partner with MW IEFS Sales Team to ensure sufficient technician capacity to support the monthly sales; as well as to maintain support to cover expected repair volumes.  Utilize SQL and Excel tools to help in the analysis of the workload averages and trends to allow for accurate future forecasts." },
    {
        "employer": "AT&T Uverse",
        "title": "Load Manager",
		"location": "Southfield, Michigan",
        "dates": "2010 - 2014",
		"description": "Efficiently balanced the workload of Uverse service orders and repair work requests.  Recommended necessary training and identified force movement to meet business needs.   Ensured sufficient technician resources to cover forecasted Install and Repair appointments."},
	{	
		"employer": "AT&T Uverse",
        "title": "Uverse Dispatcher",
		"location": "Southfield, Michigan",
        "dates": "2008 - 2010",
		"description": "Support incoming customer calls inquiring about Uverse install and repair appointments."}
		
    ]
};

for (var job in work.jobs) {
  $("#workExperience").append(HTMLworkStart);
  var formattedEmployer=HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
  var formattedTitle=HTMLworkTitle.replace("%data%",work.jobs[job].title);
  var formattedLocation=HTMLworkLocation.replace("%data%",work.jobs[job].location);  
  var formattedEmployerTitle=formattedEmployer + formattedTitle;
  $(".work-entry:last").append(formattedEmployerTitle);

  var formattedDates=HTMLworkDates.replace("%data%",work.jobs[job].dates);
  $(".work-entry:last").append(formattedDates);
  var formattedDescription=HTMLworkDescription.replace("%data%",work.jobs[job].description);
  $(".work-entry:last").append(formattedDescription);
};


// project section copied// 

var projects = {
    "projects": [
        {
            "title": "Animal Trading Card",
            "dates": "2017",
            "description": "Web based trading card using HTML and CSS.",
            "images": ["images/Animal Trading Card.png"]
        }, {
            "title": "Build a Portfolio",
            "dates": "2017",
            "description": "Translate a pdf mockup into a real responsive website using HTML and CSS.",
            "images": ["images/Build a Portfolio.png"]
        }
    ]
};

 projects.display = function() {
	 
	projects.projects.forEach(function(project) {
		$("#projects").append(HTMLprojectStart);
 
		var formattedTitle = HTMLprojectTitle.replace("%data%", project.title);
		$(".project-entry:last").append(formattedTitle);
 
		var formattedDates = HTMLprojectDates.replace("%data%", project.dates);
		$(".project-entry:last").append(formattedDates);
 
		var formattedDescription = HTMLprojectDescription.replace("%data%", project.description);
		$(".project-entry:last").append(formattedDescription);
 
		var imageArray = project.images;
 
		imageArray.forEach(function(image) {
			var formattedImage = HTMLprojectImage.replace("%data%", image);
			$(".project-entry:last").append(formattedImage);
		});
	});
};

projects.display();

 // education section //
 
 var education = {
	
	"schools" : [{
	   
		 "name" : "Robichaud High School",
		 "location" : "Dearborn Heights, Michigan",
		 "degree" : "Diploma",
		 "majors" : "General",
		 "dates" : "1987-1991 -- ",
		 "url" : "http://westwoodschools.net/"

		}],

	"onlineCourses" : [{

		 "title" : "Front-End Web Development",
		 "school" : "Udacity",
		 "dates" : "April-Present 2017",
		 "url" : "https://www.udacity.com/"
		 
		}]
};

education.display = function() {

$("#education").append(HTMLschoolStart);

for ( var i = 0; i < education.schools.length; i ++ ) {
	var formattedschoolName = HTMLschoolName.replace("%data%", education.schools[i].name);
	var formattedschoolLocation = HTMLschoolLocation.replace("%data%", education.schools[i].location);
	var formattedschoolDegree = HTMLschoolDegree.replace("%data%", education.schools[i].degree);
	var formattedschoolMajor = HTMLschoolMajor.replace("%data%", education.schools[i].majors);
	var formattedschoolDates = HTMLschoolDates.replace("%data%", education.schools[i].dates);
	var formattedonlineURL = HTMLonlineURL.replace("%data%", education.schools[i].url);
	$(".education-entry:last").append(formattedschoolName + formattedschoolLocation);
	$(".education-entry:last").append(formattedschoolDegree);
	$(".education-entry:last").append(formattedschoolMajor);
	$(".education-entry:last").append(formattedschoolDates);
	$(".education-entry:last").append(formattedonlineURL);

}

$("#education").append(HTMLonlineClasses);

for ( var i = 0; i < education.onlineCourses.length; i ++ ) {
	$("#education").append(HTMLschoolStart);
	var formattedonlineSchool = HTMLonlineSchool.replace("%data%", education.onlineCourses[i].school);
	var formattedonlineTitle = HTMLonlineTitle.replace("%data%", education.onlineCourses[i].title);
	var formattedonlineDates = HTMLonlineDates.replace("%data%", education.onlineCourses[i].dates);
	var formattedonlineURL = HTMLonlineURL.replace("%data%", education.onlineCourses[i].url);
	$(".education-entry:last").append(formattedonlineSchool);
	$(".education-entry:last").append(formattedonlineTitle);
	$(".education-entry:last").append(formattedonlineDates);
	$(".education-entry:last").append(formattedonlineURL);

}

	};

education.display();
 

 //end education
	
$(document).click(function(loc) {
	var x = loc.pageX;
	var y = loc.pageY;

	logClicks(x,y);
});

// add google map //

$("#mapDiv").append(googleMap);


//new//

bio.display = function() {

$('#topContacts').append(formattedmobile);
var HTMLmobile = '<li class="flex-item"><span class="orange-text">mobile</span><span class="white-text">734.765.4458</span></li>';
var myMobile = bio.contacts.mobile;
var formattedMobile = HTMLmobile.replace('734.765.4458', myMobile);


$('#topContacts').append(formattedemail);
var HTMLemail = '<li class="flex-item"><span class="orange-text">email</span><span class="white-text">vwoolfolk10@yahoo.com</span></li>';
var myEmail = bio.contacts.email;
var formattedEmail = HTMLemail.replace('vwoolfolk10@yahoo.com', myEmail);

$('#topContacts').append(formattedgithub);
var HTMLgithub = '<li class="flex-item"><span class="orange-text">github</span><span class="white-text">vwoolfolk</span></li>';
var myGithub = bio.contacts.github;
var formattedGithub = HTMLgithub.replace('vwoolfolk', myGithub);

$('#topContacts').prepend(formattedlocation);
var HTMLlocation = '<li class="flex-item"><span class="orange-text">location</span><span class="white-text">Romulus, Michigan</span></li>';
var myLocation = bio.contacts.location;
var formattedLocation = HTMLlocation.replace('Romulus, Michigan', myLocation);

$('#topContacts').append(formattedlocation);
var HTMLwelcomeMsg = bio.welcomeMessage;


$('#header').append('<span>' + HTMLwelcomeMsg + '</span><hr>');
var HTMLskillsStart = '<h3 id="skills-h3">Skills at a Glance:</h3><ul id="skills" class="flex-column"></ul>';
var mySkillsstart = bio.skillsStart;
var formattedskillsStart = HTMLskillsStart.replace('Skills at a Glance:', mySkillsstart);

var HTMLbioPic = '<img src="images/Vernisha.jpg" class="biopic">';
var myBiopic = bio.bioPic;
var formattedbioPic = HTMLbioPic.replace('images/Vernisha.jpg', myBiopic);
$('#header').append('<span>' + HTMLbioPic + '</span><hr>');

$("#header").append(HTMLskillsStart);
for ( var i = 0; i < bio.skills.length; i ++ ) {
	var formattedSkills = HTMLskills.replace("%data%", bio.skills[i]);
	$("#skills").append(formattedSkills);

	
	
}	


	};

bio.display();



//jkramer13 github//

//prteshJ github//

//API key - AIzaSyDwTVXyF3wibyai-h5_AR7Uz1rCP_Cj20o


// These are the real estate listings that will be shown to the user.
        // Normally we'd have these in a database instead.
        var locations = [
          {title: 'Little Caesars Arena', location: {lat: 42.341949000, lng: -83.054694000}},
          {title: 'Masonic Temple Theater', location: {lat: 42.341770700, lng: -83.060171400}},
          {title: 'Motor City Casino', location: {lat: 42.339324000, lng: -83.067158000}},
          {title: 'Fox Theater', location: {lat: 42.338310200, lng: -83.052666200}},
          {title: 'Ford Field', location: {lat: 42.339798900, lng: -83.045548200}},
          {title: 'Detroit Opera House', location: {lat: 42.336469600, lng: -83.048807500}}
        ];

		
		
		